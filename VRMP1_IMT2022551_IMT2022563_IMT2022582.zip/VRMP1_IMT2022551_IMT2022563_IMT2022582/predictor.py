from pathlib import Path
from typing import Any, List

import numpy as np
from PIL import Image
import torch
import torch.nn as nn
from torchvision import models, transforms
from ultralytics import YOLO

# -------------------------------------------------------------------
# Class mappings (must match your training label order for CLS)
# -------------------------------------------------------------------
CLS_CLASS_MAPPING = {
    0: "long sleeve top",
    1: "short sleeve top",
    2: "shorts",
    3: "skirt",
    4: "trousers",
}

SEG_CLASS_MAPPING = {
    0: "background",
    1: "short sleeve top",
    2: "long sleeve top",
    3: "trousers",
    4: "shorts",
    5: "skirt",
}


# -------------------------------------------------------------------
# Classification model definitions
# -------------------------------------------------------------------
class CustomResNet50MultiLabel(nn.Module):
    """
    Matches checkpoints with keys:
      backbone.* and classifier.*
    where classifier is:
      Linear(2048->hidden), BN(hidden), ReLU, Dropout, Linear(hidden->num_classes)
    """
    def __init__(self, num_classes: int = 5, hidden_dim: int = 512, dropout: float = 0.3):
        super().__init__()
        base = models.resnet50(weights=None)
        self.backbone = nn.Sequential(*list(base.children())[:-2])  # conv1..layer4
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.classifier = nn.Sequential(
            nn.Linear(2048, hidden_dim),      # classifier.0
            nn.BatchNorm1d(hidden_dim),       # classifier.1
            nn.ReLU(inplace=True),            # classifier.2
            nn.Dropout(p=dropout),            # classifier.3
            nn.Linear(hidden_dim, num_classes)  # classifier.4
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.backbone(x)
        x = self.pool(x).flatten(1)
        x = self.classifier(x)
        return x


def _resolve_device(device: str) -> torch.device:
    if str(device).startswith("cuda") and torch.cuda.is_available():
        return torch.device(device)
    return torch.device("cpu")


def _extract_state_dict(obj: Any):
    """
    Returns (state_dict, meta_dict).
    Supports:
      - {"state_dict": ... , ...meta}
      - raw state_dict
    """
    if isinstance(obj, dict) and "state_dict" in obj and isinstance(obj["state_dict"], dict):
        return obj["state_dict"], obj

    if isinstance(obj, dict) and len(obj) > 0 and all(isinstance(v, torch.Tensor) for v in obj.values()):
        return obj, {}

    raise RuntimeError("Unsupported cls checkpoint format.")


def load_classification_model(folder: str, device: str) -> Any:
    dev = _resolve_device(device)
    model_dir = Path(folder) / "model_files"

    ckpt_path = None
    for name in ("cls.pth", "cls.pt"):
        p = model_dir / name
        if p.exists():
            ckpt_path = p
            break
    if ckpt_path is None:
        raise FileNotFoundError("Missing model_files/cls.pth or cls.pt")

    obj = torch.load(ckpt_path, map_location=dev)
    state_dict, meta = _extract_state_dict(obj)
    keys = list(state_dict.keys())

    img_size = int(meta.get("img_size", 224))
    thresholds = np.array(meta.get("thresholds", [0.5] * 5), dtype=np.float32)
    if thresholds.shape[0] != 5:
        thresholds = np.full(5, 0.5, dtype=np.float32)

    # Case A: custom checkpoint with backbone/classifier keys
    if any(k.startswith("backbone.") for k in keys):
        hidden_dim = int(state_dict["classifier.0.weight"].shape[0]) if "classifier.0.weight" in state_dict else 512
        num_classes = int(state_dict["classifier.4.weight"].shape[0]) if "classifier.4.weight" in state_dict else 5
        model = CustomResNet50MultiLabel(num_classes=num_classes, hidden_dim=hidden_dim, dropout=0.3)
        model.load_state_dict(state_dict, strict=True)

    # Case B: plain torchvision resnet state_dict (conv1/layer*/fc)
    else:
        model = models.resnet50(weights=None)
        in_features = model.fc.in_features
        model.fc = nn.Linear(in_features, 5)
        model.load_state_dict(state_dict, strict=True)

    model.to(dev).eval()

    tfm = transforms.Compose([
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])

    return {
        "model": model,
        "device": dev,
        "transform": tfm,
        "thresholds": thresholds,
    }


def predict_classification(model, images: List[Image.Image]) -> List[dict]:
    net = model["model"]
    dev = model["device"]
    tfm = model["transform"]
    thresholds = model["thresholds"]

    x = torch.stack([tfm(im.convert("RGB")) for im in images]).to(dev)

    with torch.no_grad():
        logits = net(x)
        probs = torch.sigmoid(logits).cpu().numpy()

    outputs = []
    for p in probs:
        y = (p >= thresholds).astype(np.int64).tolist()
        y = [int(v) for v in y[:5]]
        if len(y) < 5:
            y = y + [0] * (5 - len(y))
        outputs.append({"labels": y})
    return outputs


# -------------------------------------------------------------------
# Detection + Segmentation (YOLO)
# -------------------------------------------------------------------
def load_detection_model(folder: str, device: str) -> Any:
    dev = _resolve_device(device)
    root = Path(folder)
    model_dir = root / "model_files"

    candidates = [
        model_dir / "best.pt",
        model_dir / "seg.pt",
        model_dir / "seg.pth",
        root.parent.parent.parent / "Runs" / "task2" / "best.pt",
        root.parent.parent.parent / "Runs" / "Task2" / "best.pt",
    ]

    model_path = None
    for p in candidates:
        if p.exists():
            model_path = p
            break

    if model_path is None:
        raise FileNotFoundError(
            "Could not find YOLO weights. Checked: "
            + ", ".join(str(p) for p in candidates)
        )

    yolo = YOLO(str(model_path))
    return {
        "model": yolo,
        "device": "cuda:0" if dev.type == "cuda" else "cpu",
        "conf": 0.25,
        "iou": 0.6,
    }


def predict_detection_segmentation(model, images: List[Image.Image]) -> List[dict]:
    yolo = model["model"]
    device = model.get("device", "cpu")
    conf = float(model.get("conf", 0.25))
    iou = float(model.get("iou", 0.6))

    seg_name_to_idx = {str(name).strip().lower(): int(idx) for idx, name in SEG_CLASS_MAPPING.items()}

    source = [np.array(im.convert("RGB")) for im in images]
    pred_outputs = yolo.predict(source=source, device=device, conf=conf, iou=iou, verbose=False)

    results = []
    for image, output in zip(images, pred_outputs):
        width, height = image.size

        boxes_out = []
        scores_out = []
        labels_out = []
        masks_out = []

        boxes = output.boxes
        masks = output.masks

        if boxes is not None and len(boxes) > 0:
            xyxy = boxes.xyxy.detach().cpu().numpy()
            cls = boxes.cls.detach().cpu().numpy().astype(int)
            confs = boxes.conf.detach().cpu().numpy()

            mask_data = None
            if masks is not None and masks.data is not None:
                mask_data = masks.data.detach().cpu().numpy()

            for i in range(len(cls)):
                class_id = int(cls[i])
                class_name = None
                if hasattr(output, "names") and isinstance(output.names, dict):
                    class_name = output.names.get(class_id)
                if class_name is None:
                    class_name = str(class_id)

                seg_label = seg_name_to_idx.get(str(class_name).strip().lower())
                if seg_label is None:
                    continue

                x1, y1, x2, y2 = [float(v) for v in xyxy[i]]
                x1 = max(0.0, min(x1, float(width)))
                y1 = max(0.0, min(y1, float(height)))
                x2 = max(0.0, min(x2, float(width)))
                y2 = max(0.0, min(y2, float(height)))
                if x2 <= x1 or y2 <= y1:
                    continue

                if mask_data is not None and i < len(mask_data):
                    raw_mask = mask_data[i]
                    mask_img = Image.fromarray((raw_mask > 0.5).astype(np.uint8) * 255)
                    mask_img = mask_img.resize((width, height), Image.NEAREST)
                    mask_bin = (np.array(mask_img, dtype=np.uint8) > 127).astype(np.uint8)
                else:
                    mask_bin = np.zeros((height, width), dtype=np.uint8)
                    x1i = int(np.floor(x1))
                    y1i = int(np.floor(y1))
                    x2i = int(np.ceil(x2))
                    y2i = int(np.ceil(y2))
                    mask_bin[max(0, y1i):min(height, y2i), max(0, x1i):min(width, x2i)] = 1

                boxes_out.append([x1, y1, x2, y2])
                scores_out.append(float(confs[i]))
                labels_out.append(seg_label)
                masks_out.append(mask_bin)

        results.append({
            "boxes": boxes_out,
            "scores": scores_out,
            "labels": labels_out,
            "masks": masks_out,
        })
    return results